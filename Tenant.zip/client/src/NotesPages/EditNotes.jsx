import React from "react";

export default function EditNotes() {
  return <div>EditNotes</div>;
}
